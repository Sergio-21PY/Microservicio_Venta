package cl.duocventa.Perfulandia.MicroservicioVenta.controller;

import cl.duocventa.Perfulandia.MicroservicioVenta.model.Venta;
import cl.duocventa.Perfulandia.MicroservicioVenta.services.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/perfulandia/ventas")
public class VentaController {

    @Autowired
    private VentaService ventaservice;

    @GetMapping
    public ResponseEntity<List<Venta>> listar() {
        List<Venta> ventas = this.ventaservice.buscarTodasLasVentas();
        if (ventas.isEmpty()) {
            System.out.println("No se encontro ninguna venta");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ventas);
        }else {
            System.out.println("Se encontraron ventas");
            ResponseEntity.status(HttpStatus.OK).body(ventas);

        }
        return null;
    }
}
