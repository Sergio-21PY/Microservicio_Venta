package cl.duocventa.Perfulandia.MicroservicioVenta.services;

import cl.duocventa.Perfulandia.MicroservicioVenta.model.Venta;
import cl.duocventa.Perfulandia.MicroservicioVenta.repository.VentaRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class VentaService   {

    @Autowired
    private VentaRepository ventarepository;

    public List<Venta> buscarTodasLasVentas(){
        return ventarepository.findAll();
    }

}
