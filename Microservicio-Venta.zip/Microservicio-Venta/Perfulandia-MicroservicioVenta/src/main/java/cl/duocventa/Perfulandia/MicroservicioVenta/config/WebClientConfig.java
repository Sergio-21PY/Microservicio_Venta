package cl.duocventa.Perfulandia.MicroservicioVenta.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration // Indica que la clase es de configuracion
public class WebClientConfig {


}
