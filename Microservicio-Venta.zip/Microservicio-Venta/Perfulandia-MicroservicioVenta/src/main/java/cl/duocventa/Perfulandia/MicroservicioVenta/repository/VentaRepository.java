package cl.duocventa.Perfulandia.MicroservicioVenta.repository;

import cl.duocventa.Perfulandia.MicroservicioVenta.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VentaRepository extends JpaRepository<Venta, String> {
}
