package cl.duocventa.Perfulandia.MicroservicioVenta.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name="VENTAS")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Venta {

    @Id
    @Column(nullable = false)
    private String id_venta;

    @Column(nullable = false)
    private Date fecha;

    @Column(nullable = false)
    private int total;

    @Column(nullable = false)
    private String estado;




}
