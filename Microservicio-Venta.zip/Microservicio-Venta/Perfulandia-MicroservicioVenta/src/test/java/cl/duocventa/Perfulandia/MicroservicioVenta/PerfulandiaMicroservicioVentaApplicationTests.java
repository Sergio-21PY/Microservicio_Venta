package cl.duocventa.Perfulandia.MicroservicioVenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaMicroservicioVentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
